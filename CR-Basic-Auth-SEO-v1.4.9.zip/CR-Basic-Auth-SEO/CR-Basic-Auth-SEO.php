<?php

/**
 * Plugin Name: CR Basic Auth & Meta SEO
 * Description: This plugin adds basic authentication and Yoast SEO meta updates to the WordPress REST API. You can use this plugin to login using basic username and password when doing autopost using Content Reborn AI. It also allows you to update Yoast SEO meta data such as meta descriptions and focus keywords through the REST API, providing an enhanced and automated SEO management capability for your posts.
 * Author: Eriarmedia.com
 * Author URI: https://contentreborn.com/
 * Version: 1.4.9
 * License: GPL2+
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 */


add_filter( 'determine_current_user', 'basic_auth_login', 20 );

function basic_auth_login( $user ) {
    if ( !empty($user) ) {
        return $user;
    }

    if ( !isset( $_SERVER['PHP_AUTH_USER'] ) ) {
        return $user;
    }

    $username = $_SERVER['PHP_AUTH_USER'];
    $password = $_SERVER['PHP_AUTH_PW'];

    $user = wp_authenticate($username, $password);

    if ( is_wp_error($user) ) {
        return null;
    }

    return $user->ID;
}

add_action( 'rest_api_init', function () {
    register_rest_route( 'wp/v2', '/sites', array(
        'methods' => 'GET',
        'callback' => 'get_multisite_sites',
        'permission_callback' => '__return_true'
    ));

    register_rest_route('wp/v2', '/sitesdata', array(
        'methods' => 'GET',
        'callback' => 'get_sites_data',
		'permission_callback' => '__return_true' //is_user_logged_in
    ));
});

function get_multisite_sites( $request ) {
    if ( !is_multisite() ) {
        return new WP_Error( 'not_multisite', 'This is not a multisite installation.', array( 'status' => 400 ) );
    }

    $sites = get_sites();
    $sites_data = array();

    foreach ( $sites as $site ) {
        switch_to_blog( $site->blog_id );
        $site_details = array(
            'id'     => $site->blog_id,
            'domain' => $site->domain,
            'path'   => $site->path,
            'name'   => get_bloginfo( 'name' ),
            'description' => get_bloginfo( 'description' ),
        );
        array_push( $sites_data, $site_details );
        restore_current_blog();
    }

    return new WP_REST_Response( $sites_data, 200 );
}

function get_sites_data($request)
{
    $user = wp_get_current_user();
	
	$username = empty($_GET["username"])?'username':$_GET["username"];
    $password = empty($_GET["password"])?'password':$_GET["password"];

    if (!is_multisite()) {
        return new WP_Error('not_multisite', 'This is not a multisite installation.', array('status' => 400));
    }

    $sites = get_sites();
    $domains = array();

    foreach ($sites as $site) {
        $domain = "https://{$site->domain};{$username};{$password};1";
        array_push($domains, $domain);
    }

    //return new WP_REST_Response($domains, 200);
    $response = implode("\n", $domains);
    header('Content-Type: text/plain');
    echo $response;
    exit;
}

add_action('rest_after_insert_post', 'update_seo_meta_from_rest', 10, 2);

function update_seo_meta_from_rest($post, $request) {
    $postID = $post->ID;

    // Cek apakah variabel CR_meta_trigger ada dan bernilai true
    if (isset($request['CR_meta_trigger']) && $request['CR_meta_trigger']) {
        handleMetaUpdates($postID, $request);
        handleTagCreation($postID, $request);
        handleCategoryCreation($postID, $request);
    }
	
	if (isset($request['CR_randAuthor_trigger']) && $request['CR_randAuthor_trigger']) {
		assign_random_author_to_post($post);
	}
}

function handleMetaUpdates($postID, $request) {
    $metadesc = $request['seo_meta_desc'] ?? '';
    $focuskw = $request['seo_focus_kw'] ?? '';

    if (!empty($metadesc)) {
        // Update meta description
        update_post_meta($postID, '_yoast_wpseo_metadesc', $metadesc);
        update_post_meta($postID, 'rank_math_description', $metadesc);
        // update_post_meta($postID, '_aioseo_description', $metadesc);
	update_post_meta($postID, '_seopress_titles_desc', $metadesc); // SEOpress
    }

    if (!empty($focuskw)) {
        // Update focus keyword
        update_post_meta($postID, '_yoast_wpseo_focuskw', $focuskw);
        update_post_meta($postID, 'rank_math_focus_keyword', $focuskw);
        // update_post_meta($postID, '_aioseo_keywords', $focuskw);
        update_post_meta($postID, '_seopress_analysis_target_kw', $focuskw); // SEOpress
	//update_post_meta($postID, '_seopress_titles_title', $focuskw); // SEOpress
    }
}

function handleTagCreation($postID, $request) {
    if (isset($request['CR_meta_trigger_addtags']) && !empty($request['CR_meta_trigger_addtags'])) {
        $tagsToCreate = explode(',', $request['CR_meta_trigger_addtags']);
        foreach ($tagsToCreate as $tagName) {
            $tagId = createTagIfNotExists(trim($tagName));
            if ($tagId !== false) {
                wp_set_post_tags($postID, [(int) $tagId], true); // Pastikan $tagId adalah integer
            }
        }
    }
}

function createTagIfNotExists($tagName) {
    // Cek apakah tag sudah ada
    $existingTag = term_exists($tagName, 'post_tag');
    if ($existingTag && is_array($existingTag)) {
        return (int) $existingTag['term_id']; // Pastikan mengembalikan integer
    }

    // Membuat tag baru
    $newTag = wp_insert_term($tagName, 'post_tag');
    if (is_wp_error($newTag)) {
        return false;
    }

    return (int) $newTag['term_id']; // Pastikan mengembalikan integer
}

function handleCategoryCreation($postID, $request) {
    if (isset($request['CR_meta_trigger_addcategories']) && !empty($request['CR_meta_trigger_addcategories'])) {
        $categoriesToCreate = explode(',', $request['CR_meta_trigger_addcategories']);
        $newCategoryIds = array();

        foreach ($categoriesToCreate as $categoryName) {
            $categoryId = createCategoryIfNotExists(trim($categoryName));
            if ($categoryId !== false) {
                array_push($newCategoryIds, (int) $categoryId);
            }
        }

        if (!empty($newCategoryIds)) {
            $currentCategories = wp_get_post_categories($postID, array('fields' => 'ids'));
            $uncategorizedId = get_cat_ID('Uncategorized');

            if (($key = array_search($uncategorizedId, $currentCategories)) !== false) {
                unset($currentCategories[$key]); // Menghapus 'Uncategorized'
            }

            $updatedCategories = array_merge($currentCategories, $newCategoryIds);
            wp_set_post_categories($postID, $updatedCategories);
        }
    }
}

function createCategoryIfNotExists($categoryName) {
    // Cek apakah kategori sudah ada
    $existingCategory = term_exists($categoryName, 'category');
    if ($existingCategory && is_array($existingCategory)) {
        return (int) $existingCategory['term_id']; // Pastikan mengembalikan integer
    }

    // Membuat kategori baru
    $newCategory = wp_insert_term($categoryName, 'category');
    if (is_wp_error($newCategory)) {
        return false;
    }

    return (int) $newCategory['term_id']; // Pastikan mengembalikan integer
}

add_action( 'rest_api_init', function () {
    register_rest_route( 'wp/v2', '/authors', array(
        'methods' => 'GET',
        'callback' => 'get_authors_info',
        'permission_callback' => '__return_true'
    ));
});

function get_authors_info( $request ) {
    $args = array(
        'who' => 'authors'
    );

    $authors = get_users($args);
    $authors_info = array();

    foreach ($authors as $author) {
        $author_info = array(
            'id' => $author->ID,
            'name' => $author->display_name,
            'bio' => get_the_author_meta('description', $author->ID)
        );

        array_push($authors_info, $author_info);
    }

    return new WP_REST_Response($authors_info, 200);
}

function assign_random_author_to_post($post) {
    $args = array(
        'who' => 'authors'
    );

    $authors = get_users($args);
    if (count($authors) > 0) {
        $random_author = $authors[array_rand($authors)];
        wp_update_post(array(
            'ID'          => $post->ID,
            'post_author' => $random_author->ID
        ));
    }
}

// TRIAL MAKE AUTHOR AUTOMATIS
function create_multiple_authors_permission_check($request) {
    return current_user_can('create_users');
}

function create_multiple_authors($request) {
    $authors_data = json_decode($request->get_body(), true);

    $created_authors = [];
    foreach ($authors_data as $author_data) {
        // Membuat user baru
        $userdata = array(
            // 'user_login' => $author_data['name'],
            'user_login' => strtolower(str_replace(' ', '', $author_data['display_name'])),
            'user_pass'  => wp_generate_password(), // Membuat password acak
            'user_email' => isset($author_data['email']) ? $author_data['email'] : '',
            'role'       => $author_data['role'],
            // 'display_name' => isset($author_data['display_name']) ? $author_data['display_name'] : $author_data['name']
            'first_name' => isset($author_data['display_name']) ? $author_data['display_name'] : $author_data['name']
        );

        $user_id = wp_insert_user($userdata);

        // Jika pembuatan user berhasil
        if (!is_wp_error($user_id)) {
            // Set bio (deskripsi)
            if (isset($author_data['bio'])) {
                update_user_meta($user_id, 'description', $author_data['bio']);
            }

            $created_authors[] = array(
                'id' => $user_id,
                'name' => $author_data['name'],
                'role' => $author_data['role'],
                'bio' => isset($author_data['bio']) ? $author_data['bio'] : '',
                'display_name' => isset($author_data['display_name']) ? $author_data['display_name'] : $author_data['name']
            );
        }
    }

    return new WP_REST_Response($created_authors, 200);
}

add_action('rest_api_init', function () {
    register_rest_route('wp/v2', '/make_authors', array(
        'methods' => 'POST',
        'callback' => 'create_multiple_authors',
        'permission_callback' => 'create_multiple_authors_permission_check'
    ));
});

/////////////////////////////////
function create_multiple_categories_permission_check($request) {
    return current_user_can('manage_categories');
}

function create_multiple_categories($request) {
    $categories_data = json_decode($request->get_body(), true);

    $created_categories = [];
    foreach ($categories_data as $category_data) {
        $category_id = createCategoryIfNotExists($category_data['name']);

        if ($category_id) {
            $created_categories[] = array(
                'id' => $category_id,
                'name' => $category_data['name']
            );
        }
    }

    return new WP_REST_Response($created_categories, 200);
}

add_action('rest_api_init', function () {
    register_rest_route('wp/v2', '/make_categories', array(
        'methods' => 'POST',
        'callback' => 'create_multiple_categories',
        'permission_callback' => 'create_multiple_categories_permission_check'
    ));
});
////////////////////////////////


add_action('init', 'add_cors_http_header');
function add_cors_http_header() {
    // Allow from any origin
    if (isset($_SERVER['HTTP_ORIGIN'])) {
        // Decide if the origin in $_SERVER['HTTP_ORIGIN'] is one you want to allow, or as below, allow all
        header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
        header('Access-Control-Allow-Credentials: true');
        header('Access-Control-Max-Age: 86400');    // Cache for 1 day
    }

    // Access-Control headers are received during OPTIONS requests
    if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
        
        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
            header("Access-Control-Allow-Methods: GET, POST, OPTIONS");         

        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
            header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");
        
        exit(0);
    }
}

// Be sure to include this header conditionally based on your specific security needs
// This example opens up everything which might not be suitable for a production environment

add_action('wp_ajax_process_multisite_creation', 'process_multisite_creation');
add_action('wp_ajax_nopriv_process_multisite_creation', 'process_multisite_creation');

function process_multisite_creation() {
    // Check for necessary POST fields
    if (empty($_POST['adminUsername']) || empty($_POST['adminPassword'])) {
        wp_send_json_error('Username and password are required.');
        return;
    }

    $username = sanitize_text_field($_POST['adminUsername']);
    $password = sanitize_text_field($_POST['adminPassword']);

    // Attempt to authenticate the user with the provided username and password
    $user = wp_authenticate($username, $password);
    
    if (is_wp_error($user)) {
        wp_send_json_error('Authentication failed: ' . $user->get_error_message() );
        return;
    }

    // Set the current user after successful authentication
    wp_set_current_user($user->ID);
    if (!current_user_can('manage_options')) {
        wp_send_json_error('Unauthorized: You do not have permission to perform this action.');
        return;
    }
    
    if (empty($_POST['siteName']) || empty($_POST['domain']) || empty($_POST['siteTitle']) || empty($_POST['tagline']) || empty($_POST['adminEmail'])) {
        wp_send_json_error('Missing necessary information');
        return;
    }
    
    if ( !is_multisite() ) {
        return new WP_Error( 'not_multisite', 'This is not a multisite installation.', array( 'status' => 400 ) );
    }

    $domain = sanitize_text_field($_POST['domain']);
    $siteName = sanitize_text_field($_POST['siteName']);
    $siteTitle = sanitize_text_field($_POST['siteTitle']);
    $tagline = sanitize_text_field($_POST['tagline']);
    $adminEmail = sanitize_email($_POST['adminEmail']);
    $permalink = sanitize_text_field($_POST['permalink']);
    $cloneTheme = filter_var($_POST['cloneTheme'], FILTER_VALIDATE_BOOLEAN);
    $setLatestPosts = filter_var($_POST['setLatestPosts'], FILTER_VALIDATE_BOOLEAN);
    $removeDefault = filter_var($_POST['removeDefault'], FILTER_VALIDATE_BOOLEAN);
    $activePlugins = array_map('sanitize_text_field', (array) $_POST['activePlugins']);

    $user_id = get_current_user_id();
    $new_site_id = wpmu_create_blog($domain, '/', $siteTitle, $user_id, ['public' => 1], 1);

    if (is_wp_error($new_site_id)) {
        wp_send_json_error('Error: ' . $new_site_id->get_error_message());
        return;
    }
    
    if ($removeDefault) {
        create_mu_plugin();
    } else {
		delete_mu_plugin_folder();
	}
    
    if(!empty($_POST['verification']))
    {
        insert_html_verification($_POST['verification']);
    }

    switch_to_blog($new_site_id);

    // Update site-specific settings
    /*update_option('blogname', $siteTitle);
    update_option('blogdescription', $tagline);
    update_option('admin_email', $adminEmail);*/

    // Clone settings from the main site if requested
    if ($cloneTheme) {
        clone_site_settings(get_main_site_id(), $new_site_id);
    }
	
	/*if (!$removeDefault) {
        clone_pages(get_main_site_id(), $new_site_id);
        clone_menus(get_main_site_id(), $new_site_id);
    }*/

    // Update permalink structure and flush rewrite rules
    if (!empty($permalink)) {
        update_option('permalink_structure', $permalink);
        flush_rewrite_rules();
    }

    // Set the homepage to display the latest posts if requested
    if ($setLatestPosts) {
        update_option('show_on_front', 'posts');
        update_option('page_on_front', 0);
    }

    // Activate plugins
    foreach ($activePlugins as $plugin) {
        if (!empty($plugin) && !is_plugin_active($plugin)) {
            $activation = activate_plugin($plugin);
            if (is_wp_error($activation)) {
                restore_current_blog();  // Restore to switch back before reporting error
                wp_send_json_error('Plugin activation failed: ' . $activation->get_error_message());
                return;
            }
        }
    }
	
	restore_current_blog();  // Switch back to the original site context
    wp_send_json_success('Site ' . $domain . ' created successfully.');
}

function create_mu_plugin() {
    $mu_plugins_dir = ABSPATH . 'wp-content/mu-plugins';
    $mu_plugin_file = $mu_plugins_dir . '/modify-install.php';

    if (!file_exists($mu_plugins_dir) && !mkdir($mu_plugins_dir, 0755) && !is_dir($mu_plugins_dir)) {
        error_log('Failed to create mu-plugins directory.');
        wp_send_json_error('Failed to create mu-plugins directory.');
        return;
    }

    if (!file_exists($mu_plugin_file)) {
        $content = "<?php\nif (!function_exists('wp_install_defaults')) {\n";
        $content .= "    function wp_install_defaults(\$user_id) {\n";
        $content .= "        // No default content\n    }\n}\n";

        if (file_put_contents($mu_plugin_file, $content) === false) {
            error_log('Failed to write the mu-plugin file.');
            wp_send_json_error('Failed to write the mu-plugin file.');
            return;
        }

        error_log('mu-plugin created successfully.');
    }
}

function delete_mu_plugin_folder() {
    $mu_plugins_dir = ABSPATH . 'wp-content/mu-plugins';
    $mu_plugin_file = $mu_plugins_dir . '/modify-install.php';

    // Cek apakah file modify-install.php ada
    if (file_exists($mu_plugin_file)) {
        // Hapus file modify-install.php
        if (!unlink($mu_plugin_file)) {
            // Jika penghapusan gagal, kosongkan isi file sebagai backup
            file_put_contents($mu_plugin_file, '');
            // error_log('Failed to delete modify-install.php. File content has been emptied as backup.');
        } else {
            // error_log('modify-install.php deleted successfully.');
        }
    }

    // Cek apakah folder mu-plugins ada dan kosong
    if (is_dir($mu_plugins_dir)) {
        // Hapus folder mu-plugins jika kosong
        if (!rmdir($mu_plugins_dir)) {
            error_log('Failed to delete mu-plugins directory. Ensure it is empty before deletion.');
            wp_send_json_error('Failed to delete mu-plugins directory. Ensure it is empty before deletion.');
        } else {
            error_log('mu-plugins directory deleted successfully.');
        }
    }
}

function clone_pages($source_blog_id, $target_blog_id) {
    switch_to_blog($source_blog_id);
    
    // Dapatkan semua halaman dari situs sumber
    $pages = get_posts([
        'post_type' => 'page',
        'post_status' => 'publish',
        'numberposts' => -1,
    ]);

    // Pindah ke situs target untuk mengimpor halaman
    switch_to_blog($target_blog_id);

    foreach ($pages as $page) {
        // Salin data halaman
        $new_page = [
            'post_title' => $page->post_title,
            'post_content' => $page->post_content,
            'post_status' => 'publish',
            'post_type' => 'page',
        ];
        
        // Insert halaman ke situs baru
        wp_insert_post($new_page);
    }

    restore_current_blog();
}

function clone_menus($source_blog_id, $target_blog_id) {
    // Beralih ke situs sumber untuk mengambil menu dan lokasinya
    switch_to_blog($source_blog_id);

    // Ambil semua lokasi menu dan item menu dari situs utama
    $menu_locations = get_nav_menu_locations();
    $menus = wp_get_nav_menus();

    // Array untuk menyimpan ID menu baru di situs target
    $new_menu_locations = [];
    $item_map = []; // Peta ID item lama ke item baru

    // Beralih ke situs target untuk mengimpor menu
    switch_to_blog($target_blog_id);

    foreach ($menus as $menu) {
        // Buat menu baru dengan nama yang sama di situs target
        $new_menu_id = wp_create_nav_menu($menu->name);

        if (!is_wp_error($new_menu_id)) {
            // Ambil item menu dari menu asli di situs sumber
            $menu_items = wp_get_nav_menu_items($menu->term_id);

            // Pertama, tambahkan setiap item menu tanpa memperhatikan hierarki
            foreach ($menu_items as $item) {
                // Siapkan data item menu tanpa `menu-item-parent-id`
                $item_data = [
                    'menu-item-title' => $item->title,
                    'menu-item-url' => $item->url,
                    'menu-item-status' => 'publish',
                    'menu-item-type' => $item->type,
                    'menu-item-object' => $item->object,
                    'menu-item-object-id' => $item->object_id,
                    'menu-item-position' => $item->menu_order,
                ];

                // Tambahkan item ke menu baru dan simpan ID item baru
                $new_item_id = wp_update_nav_menu_item($new_menu_id, 0, $item_data);
                $item_map[$item->ID] = $new_item_id; // Peta ID lama ke ID baru
            }

            // Kedua, update parent ID sesuai struktur menu asli
            foreach ($menu_items as $item) {
                if ($item->menu_item_parent && isset($item_map[$item->menu_item_parent])) {
                    // Update parent ID untuk item yang memiliki parent
                    wp_update_nav_menu_item($new_menu_id, $item_map[$item->ID], [
                        'menu-item-parent-id' => $item_map[$item->menu_item_parent]
                    ]);
                }
            }

            // Simpan menu baru ke array lokasi
            $new_menu_locations[$menu->term_id] = $new_menu_id;
        }
    }

    // Assign lokasi menu baru ke lokasi tema pada situs target
    $theme_locations = array();
    foreach ($menu_locations as $location => $menu_id) {
        if (isset($new_menu_locations[$menu_id])) {
            $theme_locations[$location] = $new_menu_locations[$menu_id];
        }
    }

    set_theme_mod('nav_menu_locations', $theme_locations);

    // Kembalikan ke situs asal
    restore_current_blog();
}

function insert_html_verification($names) {
    $homeverification_dir = ABSPATH .'/';
    
    // Split the input names by comma to handle multiple file names
    $filenames = explode(',', $names);

    // Iterate over each file name in the array
    foreach ($filenames as $name) {
        $name = trim($name); // Trim whitespace
        $homeverification_file = $homeverification_dir . $name;

        if (!file_exists($homeverification_file)) {
            $content = "google-site-verification: " . $name;

            if (file_put_contents($homeverification_file, $content) === false) {
                error_log('Failed to write the html_verification file for: ' . $name);
                wp_send_json_error('Failed to write the html_verification file for: ' . $name);
                continue; // Skip to the next file
            }

            error_log('html_verification for ' . $name . ' created successfully.');
        }
    }
}

function clone_site_settings($source_blog_id, $target_blog_id) {
    switch_to_blog($source_blog_id);
    $excluded_options = ['siteurl', 'home', 'blogname', 'blogdescription'/*, 'admin_email'*/];  // Exclude site-specific options
	$all_options = wp_load_alloptions();

    switch_to_blog($target_blog_id);
    foreach ($all_options as $option_name => $option_value) {
        if (!in_array($option_name, $excluded_options)) {
            update_option($option_name, maybe_unserialize($option_value));
        }
    }

    restore_current_blog();
    return true;
}

function tryMissedPosts() {
	if (is_front_page() || is_single()) {

		global $wpdb;
		$now=gmdate('Y-m-d H:i:00');
		
		//CHECK IF THERE ARE CUSTOM POST TYPES
		$args = array(
       'public'   => true,
       '_builtin' => false,
    	);

	    $output = 'names'; // names or objects, note names is the default
    	$operator = 'and'; // 'and' or 'or'
	    $post_types = get_post_types( $args, $output, $operator ); 
	
		
		if (count($post_types)===0) {
			$sql="Select ID from $wpdb->posts WHERE post_type in ('post','page') AND post_status='future' AND post_date_gmt<'$now'";
		}
		else {
			$str=implode ('\',\'',$post_types);
			$sql="Select ID from $wpdb->posts WHERE post_type in ('page','post','$str') AND post_status='future' AND post_date_gmt<'$now'";
		}
		
		$resulto = $wpdb->get_results($sql);
 		if($resulto) {
			foreach( $resulto as $thisarr ) {
				wp_publish_post($thisarr->ID);
			}
		}
	}
}
add_action('wp_head', 'tryMissedPosts'); 

// Multisite Permalinks Flush : Allows manual flushing of permalinks for all sites in a multisite WordPress installation via a menu in the dashboard.

// Fungsi untuk flush permalinks di seluruh network multisite
function flush_multisite_permalinks() {
    if (is_multisite()) {
        // Ambil semua situs dalam jaringan multisite
        $sites = get_sites();
        
        // Loop melalui setiap situs
        foreach ($sites as $site) {
            // Berpindah ke situs saat ini dalam loop
            switch_to_blog($site->blog_id);
            
            // Flush rewrite rules untuk situs saat ini
            flush_rewrite_rules();
            
            // Kembalikan ke situs utama
            restore_current_blog();
        }
    } else {
        // Jika bukan multisite, flush permalinks untuk situs tunggal
        flush_rewrite_rules();
    }
}

// Fungsi untuk menambahkan menu di dashboard
function multisite_permalinks_flush_menu() {
    // Tambahkan menu di bawah "Settings"
    add_options_page(
        'Multisite Permalinks Flush',  // Nama halaman
        'CR Permalinks Flush',            // Nama menu
        'manage_options',              // Hak akses yang dibutuhkan
        'multisite-permalinks-flush',  // Slug halaman
        'multisite_permalinks_flush_page' // Fungsi untuk menampilkan konten halaman
    );
}
add_action('admin_menu', 'multisite_permalinks_flush_menu');

// Fungsi untuk menampilkan halaman menu dan menangani proses flushing
function multisite_permalinks_flush_page() {
    // Cek apakah tombol "Flush Permalinks" diklik
    if (isset($_POST['flush_permalinks'])) {
        flush_multisite_permalinks(); // Jalankan proses flushing permalinks
        
        // Tampilkan pesan sukses
        echo '<div class="updated notice is-dismissible"><p>Permalinks flushed successfully for all sites!</p></div>';
    }
    
    // Tampilkan halaman dengan tombol "Flush Permalinks"
    ?>
    <div class="wrap">
        <h1>CR Multisite Permalinks Flush</h1>
        <p>Click the button below to flush permalinks for all sites in the multisite network.</p>
        <form method="post">
            <input type="hidden" name="flush_permalinks" value="true">
            <?php submit_button('Flush Permalinks'); ?>
        </form>
    </div>
    <?php
}

// Fungsi untuk memastikan bahwa pengguna memiliki hak akses yang cukup untuk mengakses halaman
/*function multisite_permalinks_flush_check_permissions() {
    if (!current_user_can('manage_options')) {
        wp_die(__('You do not have sufficient permissions to access this page.'));
    }
}
add_action('admin_init', 'multisite_permalinks_flush_check_permissions');*/
